import { Button } from "@/components/ui/button";

const programs = [
  {
    name: "Mini-Formations",
    price: "Dès 47€",
    desc: "Modules rapides, action directe (1h–2h).",
    bullets: [
      "Créer son agent IA (WhatsApp)",
      "Automatisation Make (workflow)",
      "Site pro (Next.js + Vercel)",
    ],
    ribbon: null,
  },
  {
    name: "IA Masterclass",
    price: "297€",
    desc: "Le programme complet (6 semaines) + templates.",
    bullets: [
      "Architecture agents & outils",
      "Offres, pricing, closing",
      "Playbooks + support",
    ],
    ribbon: "BEST SELLER",
  },
  {
    name: "Business Academy",
    price: "Dès 97€",
    desc: "Stratégie & marketing pour scaler.",
    bullets: [
      "Positionnement & offre",
      "Contenu qui convertit",
      "Systèmes de vente",
    ],
    ribbon: null,
  },
];

const faqs = [
  {
    q: "Est-ce que c'est adapté si je débute ?",
    a: "Oui. On part de 0 et on va jusqu'à un système complet : offre → acquisition → automation → delivery.",
  },
  {
    q: "Je peux apprendre sur téléphone ?",
    a: "Oui. Les supports sont mobile-friendly et on donne des checklists rapides.",
  },
  {
    q: "Y'a une certification ?",
    a: "La Masterclass inclut une attestation + un audit de ton système (si tu completes les étapes).",
  },
];

export default function AcademyPage() {
  return (
    <div className="max-w-7xl mx-auto px-4">
      <div className="pt-6 pb-10">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-[10px] font-bold tracking-widest text-gray-300">
          <span className="w-2 h-2 rounded-full bg-emerald-400" />
          ACADEMY
        </div>
        <h1 className="mt-4 text-4xl md:text-6xl font-display font-bold">Applix Academy</h1>
        <p className="mt-3 text-gray-400 max-w-2xl">
          Passe de 0 à "système" : offre + marketing + automatisation. Sans blabla.
        </p>

        <div className="mt-6 flex flex-col sm:flex-row gap-3">
          <Button className="rounded-full">Voir les programmes</Button>
          <Button variant="outline" className="rounded-full border-white/10 bg-white/5 hover:bg-white/10">
            Demander le syllabus
          </Button>
        </div>
      </div>

      <div className="grid md:grid-cols-3 gap-6">
        {programs.map((p) => (
          <div
            key={p.name}
            className={`relative rounded-3xl border border-white/10 bg-white/[0.03] p-6 ${p.ribbon ? "md:scale-[1.03] shadow-2xl" : ""}`}
          >
            {p.ribbon ? (
              <div className="absolute top-4 right-4 text-[10px] font-bold px-2 py-1 rounded-full bg-[#E3B52E] text-black">
                {p.ribbon}
              </div>
            ) : null}
            <div className="text-xs font-bold tracking-widest text-white/50 uppercase">Programme</div>
            <h3 className="mt-2 text-xl font-bold">{p.name}</h3>
            <p className="mt-2 text-sm text-gray-400">{p.desc}</p>
            <div className="mt-4 text-2xl font-display font-bold text-[#E3B52E]">{p.price}</div>

            <ul className="mt-5 space-y-2 text-sm text-gray-300">
              {p.bullets.map((b) => (
                <li key={b} className="flex gap-2">
                  <span className="mt-2 h-1.5 w-1.5 rounded-full bg-[#E3B52E]" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>

            <Button className="mt-6 w-full rounded-xl">Rejoindre</Button>
          </div>
        ))}
      </div>

      <div className="mt-12 rounded-3xl border border-white/10 bg-black/40 p-6 md:p-8">
        <h2 className="text-xl font-bold">Comment ça se passe</h2>
        <div className="mt-6 grid md:grid-cols-4 gap-4 text-sm">
          {[
            { t: "1. Setup", d: "Accès, templates, objectifs" },
            { t: "2. Build", d: "Offre + funnel + pages" },
            { t: "3. Automate", d: "Workflows + agents" },
            { t: "4. Scale", d: "Ads, SOP, delivery" },
          ].map((s) => (
            <div key={s.t} className="rounded-2xl border border-white/10 bg-white/[0.03] p-4">
              <div className="font-bold">{s.t}</div>
              <div className="text-gray-400 mt-1">{s.d}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="mt-12 grid md:grid-cols-2 gap-6">
        <div className="rounded-3xl border border-white/10 bg-white/[0.03] p-6">
          <h3 className="font-bold">FAQ</h3>
          <div className="mt-4 space-y-4">
            {faqs.map((f) => (
              <div key={f.q} className="rounded-2xl border border-white/10 bg-black/30 p-4">
                <div className="font-semibold">{f.q}</div>
                <div className="mt-2 text-sm text-gray-400">{f.a}</div>
              </div>
            ))}
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-gradient-to-b from-[#E3B52E]/10 to-transparent p-6">
          <h3 className="font-bold">Tu veux un parcours perso ?</h3>
          <p className="mt-2 text-sm text-gray-400">
            On peut mapper ton objectif et te donner la roadmap (pages + workflows + templates).
          </p>
          <Button className="mt-6 rounded-xl">Demander un audit</Button>
          <p className="mt-3 text-[11px] text-gray-500">Sans login. Paiement/commande via WhatsApp pour l'instant.</p>
        </div>
      </div>

      <div className="h-16" />
    </div>
  );
}
