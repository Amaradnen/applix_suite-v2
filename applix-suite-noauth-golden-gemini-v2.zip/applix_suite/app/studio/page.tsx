import { Button } from "@/components/ui/button";

const services = [
  {
    title: "Contenu & Production",
    bullets: ["Reels / TikTok (script + montage)", "Photos pro (produit / perso)", "Brand kit (logo, palette, typos)", "Showreel & promos"],
    accent: "from-sky-500/20 to-transparent",
  },
  {
    title: "Ads & Acquisition",
    bullets: ["Meta Ads (FB/IG)", "TikTok Ads", "Tracking (Pixel/CAPI)", "Optimisation ROAS"],
    accent: "from-violet-500/20 to-transparent",
  },
  {
    title: "Sites & Funnels",
    bullets: ["Landing pages conversion", "Site vitrine premium", "E-commerce (Shopify/Next)", "Lead forms + CRM"],
    accent: "from-amber-500/20 to-transparent",
  },
];

const process = [
  { step: "01", title: "Audit express", desc: "Objectif, offre, angle, cibles, actifs existants." },
  { step: "02", title: "Plan d'attaque", desc: "Scripts, concepts, structure funnel + tracking." },
  { step: "03", title: "Production", desc: "Création des assets (UGC/Reels, visuels, LP)." },
  { step: "04", title: "Scaling", desc: "Tests, itérations, reporting clair, montée en budget." },
];

const caseStudies = [
  { kpi: "+38%", title: "Conversion Landing", desc: "Refonte structure + preuves sociales + CTA." },
  { kpi: "-27%", title: "CPA Meta", desc: "Nouveaux angles + créas UGC + retarget." },
  { kpi: "x2.1", title: "Leads qualifiés", desc: "Formulaire intelligent + tri WhatsApp." },
];

const faqs = [
  { q: "Vous faites le contenu ET les pubs ?", a: "Oui. Le meilleur ROI vient d'un système complet : créas → funnel → tracking → optimisation." },
  { q: "Délais de livraison ?", a: "En général : 3–7 jours pour un pack créas, 7–14 jours pour une landing page complète (selon assets)." },
  { q: "Vous travaillez avec quelles niches ?", a: "On est à l'aise avec : immo, restauration, cliniques, salons, creators, e‑commerce." },
];

export default function StudioPage() {
  return (
    <div className="mx-auto w-full max-w-6xl px-4 py-10">
      <div className="relative overflow-hidden rounded-3xl border border-white/10 bg-white/5 p-8">
        <div className="pointer-events-none absolute -right-24 -top-24 h-64 w-64 rounded-full bg-violet-500/15 blur-3xl" />
        <div className="pointer-events-none absolute -left-24 -bottom-24 h-64 w-64 rounded-full bg-sky-500/10 blur-3xl" />

        <div className="flex flex-col gap-6 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="text-xs font-bold tracking-widest text-white/50">APPLIX STUDIO</p>
            <h1 className="mt-2 font-display text-4xl font-bold">Creative that sells.</h1>
            <p className="mt-3 max-w-xl text-sm text-white/70">
              Même style Golden Gemini. On produit des créas, des funnels et des Ads avec une logique simple :
              preuves sociales + angle + tracking.
            </p>
          </div>

          <div className="flex flex-col gap-3 sm:flex-row">
            <Button className="rounded-xl bg-white text-black hover:bg-gray-200">Demander un devis</Button>
            <Button variant="outline" className="rounded-xl border-white/10 bg-white/5 text-white hover:bg-white/10">
              Voir des exemples
            </Button>
          </div>
        </div>
      </div>

      <section className="mt-10 grid gap-6 md:grid-cols-3">
        {services.map((s) => (
          <div key={s.title} className="relative overflow-hidden rounded-2xl border border-white/10 bg-white/5 p-6">
            <div className={`pointer-events-none absolute inset-0 bg-gradient-to-br ${s.accent}`} />
            <h2 className="relative text-lg font-bold">{s.title}</h2>
            <ul className="relative mt-4 space-y-2 text-sm text-white/80">
              {s.bullets.map((b) => (
                <li key={b} className="flex gap-2">
                  <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#E3B52E]" />
                  <span>{b}</span>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </section>

      <section className="mt-12">
        <div className="flex items-end justify-between gap-4">
          <div>
            <h2 className="text-2xl font-bold">Process simple, résultats clairs</h2>
            <p className="mt-2 text-sm text-white/70">Inspiré des meilleures agences : audit → plan → production → scaling.</p>
          </div>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-4">
          {process.map((p) => (
            <div key={p.step} className="rounded-2xl border border-white/10 bg-white/5 p-5">
              <div className="text-xs font-bold tracking-widest text-[#E3B52E]">{p.step}</div>
              <div className="mt-2 font-bold">{p.title}</div>
              <div className="mt-2 text-sm text-white/70">{p.desc}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-12">
        <h2 className="text-2xl font-bold">Cas d'usage (exemples)</h2>
        <p className="mt-2 text-sm text-white/70">Des formats KPI comme sur les sites leader : rapide à comprendre.</p>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {caseStudies.map((c) => (
            <div key={c.title} className="rounded-2xl border border-white/10 bg-white/5 p-6">
              <div className="text-4xl font-display font-bold text-[#E3B52E]">{c.kpi}</div>
              <div className="mt-2 font-bold">{c.title}</div>
              <div className="mt-2 text-sm text-white/70">{c.desc}</div>
            </div>
          ))}
        </div>
      </section>

      <section className="mt-12 grid gap-6 md:grid-cols-2">
        <div className="rounded-3xl border border-white/10 bg-white/5 p-7">
          <h2 className="text-xl font-bold">Pack "Launch" (recommandé)</h2>
          <p className="mt-2 text-sm text-white/70">Pour lancer vite : contenu + landing + tracking.</p>
          <ul className="mt-4 space-y-2 text-sm text-white/80">
            {["10 créas (Reels/UGC)", "1 landing page conversion", "Pixel + CAPI + event setup", "1 semaine d'optimisation"].map((x) => (
              <li key={x} className="flex gap-2">
                <span className="mt-1.5 h-1.5 w-1.5 rounded-full bg-[#E3B52E]" />
                <span>{x}</span>
              </li>
            ))}
          </ul>
          <div className="mt-6 flex flex-col gap-3 sm:flex-row sm:items-center">
            <Button className="rounded-xl bg-[#E3B52E] text-black hover:bg-[#E3B52E]/90">Réserver</Button>
            <span className="text-xs text-white/60">Prix sur devis (selon niche & volume)</span>
          </div>
        </div>

        <div className="rounded-3xl border border-white/10 bg-white/5 p-7">
          <h2 className="text-xl font-bold">FAQ</h2>
          <div className="mt-4 space-y-4">
            {faqs.map((f) => (
              <div key={f.q} className="rounded-2xl border border-white/10 bg-black/20 p-5">
                <div className="font-bold">{f.q}</div>
                <div className="mt-2 text-sm text-white/70">{f.a}</div>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
