"use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";

type Offer = {
  name: string;
  category: "Streaming" | "IA" | "Music" | "Social";
  price: string;
  old?: string;
  desc: string;
  badge?: string;
};

const offers: Offer[] = [
  { name: "Netflix 4K", category: "Streaming", price: "5€", old: "19€", desc: "Compte partagé / UHD", badge: "Top" },
  { name: "Shahid VIP", category: "Streaming", price: "4€", old: "12€", desc: "Sport & séries arabe", badge: "VIP" },
  { name: "Spotify Premium", category: "Music", price: "3€", old: "10€", desc: "Musique sans pub" },
  { name: "YouTube Premium", category: "Streaming", price: "3€", old: "13€", desc: "Sans pub + Music" },
  { name: "ChatGPT Plus (shared)", category: "IA", price: "8€", old: "22€", desc: "Accès partagé (selon stock)", badge: "IA" },
  { name: "Pack IA", category: "IA", price: "15€", old: "60€", desc: "GPT + Gemini + Midjourney" },
  { name: "TikTok Coins", category: "Social", price: "-30%", old: "Official", desc: "Recharge business / ads" },
  { name: "Canva Pro", category: "Social", price: "4€", old: "15€", desc: "Design pro (selon stock)" },
];

const cats: Array<Offer["category"] | "All"> = ["All", "Streaming", "IA", "Music", "Social"];

export default function HubPage() {
  const [cat, setCat] = useState<(typeof cats)[number]>("All");

  const filtered = useMemo(() => {
    if (cat === "All") return offers;
    return offers.filter((o) => o.category === cat);
  }, [cat]);

  return (
    <div className="max-w-6xl mx-auto">
      <div className="glass-card border border-white/10 rounded-3xl p-8 mb-8">
        <div className="flex flex-col md:flex-row md:items-end md:justify-between gap-6">
          <div>
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full border border-white/10 bg-white/5 text-[10px] font-bold tracking-widest text-gold">
              HUB VIP • PRIX GROSSISTE
            </div>
            <h1 className="mt-4 text-4xl md:text-5xl font-display font-bold">Subscriptions Hub</h1>
            <p className="mt-3 text-white/70 max-w-2xl">
              Catalogue revendeur : streaming, IA, logiciels & crédits. Livraison rapide + support.
            </p>
          </div>

          <div className="flex gap-3">
            <Button className="rounded-full bg-white text-black hover:bg-white/90">Commander sur WhatsApp</Button>
            <Button variant="outline" className="rounded-full border-white/20">
              Accès API (plus tard)
            </Button>
          </div>
        </div>
      </div>

      <div className="flex flex-wrap gap-2 mb-6">
        {cats.map((c) => (
          <button
            key={c}
            onClick={() => setCat(c)}
            className={`px-4 py-2 rounded-full text-xs font-bold border transition ${
              cat === c ? "bg-white/10 border-white/20 text-white" : "bg-white/5 border-white/10 text-white/70 hover:text-white"
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((o) => (
          <div key={o.name} className="glass-card border border-white/10 rounded-2xl p-6 relative overflow-hidden">
            {o.badge ? (
              <div className="absolute top-4 right-4 text-[10px] font-bold tracking-widest px-2 py-1 rounded-full bg-gold/10 text-gold border border-gold/20">
                {o.badge}
              </div>
            ) : null}

            <div className="text-xs font-bold text-white/50 tracking-widest uppercase">{o.category}</div>
            <h3 className="mt-2 text-lg font-bold">{o.name}</h3>
            <p className="mt-2 text-sm text-white/70">{o.desc}</p>

            <div className="mt-5 flex items-end justify-between">
              <div>
                <div className="text-3xl font-display font-bold">{o.price}</div>
                {o.old ? <div className="text-xs text-white/40 line-through">{o.old}</div> : null}
              </div>
              <Button className="rounded-full bg-gold text-black hover:bg-gold/90">Commander</Button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-10 grid md:grid-cols-3 gap-6">
        {["Livraison", "Renouvellement", "Garantie"].map((t, i) => (
          <div key={t} className="glass-card border border-white/10 rounded-2xl p-6">
            <div className="text-xs font-bold tracking-widest text-white/50 uppercase">{t}</div>
            <p className="mt-3 text-sm text-white/70">
              {i === 0 && "Activation guidée + instructions. Livraison généralement sous 5–30 min (selon stock)."}
              {i === 1 && "Vous choisissez : mensuel / trimestriel / annuel. Rappel automatique possible."}
              {i === 2 && "Si un accès tombe dans les premiers jours : remplacement (selon conditions)."}
            </p>
          </div>
        ))}
      </div>

      <div className="mt-10 glass-card border border-gold/20 rounded-3xl p-8 bg-gold/5">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-5">
          <div>
            <h2 className="text-2xl font-display font-bold">Mode Revendeur</h2>
            <p className="mt-2 text-white/70 max-w-xl">
              Objectif : vous donner un canal simple (WhatsApp puis Bot Telegram/API) pour revendre.
            </p>
          </div>
          <Button className="rounded-full bg-white text-black hover:bg-white/90">Demander l'accès revendeur</Button>
        </div>
      </div>
    </div>
  );
}
