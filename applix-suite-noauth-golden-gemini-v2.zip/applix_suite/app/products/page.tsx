"use client";

import { useMemo, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

type Product = {
  title: string;
  category: "Ebooks" | "PLR" | "Templates" | "Prompts";
  price: string;
  blurb: string;
  tags: string[];
};

const catalog: Product[] = [
  {
    title: "Marketing 2025 — Playbook",
    category: "Ebooks",
    price: "19€",
    blurb: "Tendances, hooks, angles créatifs, checklists.",
    tags: ["ads", "contenu", "tendances"],
  },
  {
    title: "PLR Business Kit",
    category: "PLR",
    price: "49€",
    blurb: "Pack revendable : pages, posts, emails, scripts.",
    tags: ["revendre", "bundles"],
  },
  {
    title: "Kit Start-up IA",
    category: "Templates",
    price: "99€",
    blurb: "Landing, pitch deck, devis, contrats, onboarding.",
    tags: ["startup", "b2b"],
  },
  {
    title: "Pack 1000 Prompts",
    category: "Prompts",
    price: "29€",
    blurb: "Prompts prêts à l’emploi (content, sales, ops).",
    tags: ["chatgpt", "gemini"],
  },
  {
    title: "Templates WhatsApp Funnel",
    category: "Templates",
    price: "39€",
    blurb: "Réponses rapides, séquences, scripts de vente.",
    tags: ["whatsapp", "closing"],
  },
  {
    title: "PLR Clinic Leads Pack",
    category: "PLR",
    price: "59€",
    blurb: "Angles + creatives + scripts pour cliniques.",
    tags: ["clinic", "meta ads"],
  },
];

const filters = ["Tous", "Ebooks", "PLR", "Templates", "Prompts"] as const;
type Filter = (typeof filters)[number];

export default function ProductsPage() {
  const [q, setQ] = useState("");
  const [filter, setFilter] = useState<Filter>("Tous");

  const items = useMemo(() => {
    const query = q.trim().toLowerCase();
    return catalog.filter((p) => {
      const passFilter = filter === "Tous" ? true : p.category === filter;
      const passQuery = query
        ? [p.title, p.blurb, p.category, ...p.tags].join(" ").toLowerCase().includes(query)
        : true;
      return passFilter && passQuery;
    });
  }, [q, filter]);

  return (
    <div className="mx-auto max-w-6xl px-4 py-10">
      <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
        <div>
          <div className="text-xs font-bold tracking-[0.25em] text-white/50 uppercase">DIGITAL PRODUCTS</div>
          <h1 className="mt-2 text-3xl md:text-4xl font-display font-bold">Librairie Applix</h1>
          <p className="mt-2 text-white/70 max-w-xl">
            Ebooks, PLR, templates et prompts — pensés pour vendre, livrer vite, et scaler.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 sm:items-center">
          <Input
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Rechercher (ads, whatsapp, clinic...)"
            className="w-full sm:w-80 bg-white/5 border-white/10"
          />
          <Button className="bg-gold text-black hover:bg-gold/90">Vendre ce pack</Button>
        </div>
      </div>

      <div className="mb-6 flex flex-wrap gap-2">
        {filters.map((f) => (
          <button
            key={f}
            onClick={() => setFilter(f)}
            className={
              "px-4 py-2 rounded-full text-xs font-bold border transition " +
              (filter === f
                ? "bg-white/10 border-white/20 text-white"
                : "bg-transparent border-white/10 text-white/60 hover:text-white hover:border-white/20")
            }
          >
            {f}
          </button>
        ))}
      </div>

      <div className="grid gap-4 md:grid-cols-2">
        {items.map((p) => (
          <div key={p.title} className="rounded-2xl border border-white/10 bg-white/5 p-5">
            <div className="flex items-start justify-between gap-3">
              <div>
                <div className="text-[10px] font-bold tracking-[0.25em] uppercase text-white/50">{p.category}</div>
                <h3 className="mt-2 text-lg font-bold text-white">{p.title}</h3>
                <p className="mt-1 text-sm text-white/70">{p.blurb}</p>
              </div>
              <div className="text-right">
                <div className="text-xl font-display font-bold text-gold">{p.price}</div>
                <div className="mt-1 text-[10px] text-white/50">Paiement WhatsApp / Stripe</div>
              </div>
            </div>

            <div className="mt-4 flex flex-wrap gap-2">
              {p.tags.map((t) => (
                <span
                  key={t}
                  className="text-[10px] font-bold px-2 py-1 rounded-full bg-black/30 border border-white/10 text-white/70"
                >
                  #{t}
                </span>
              ))}
            </div>

            <div className="mt-5 flex flex-col sm:flex-row gap-3">
              <Button variant="secondary" className="bg-white text-black hover:bg-white/90">Voir détails</Button>
              <Button className="bg-gold text-black hover:bg-gold/90">Acheter</Button>
            </div>
          </div>
        ))}
      </div>

      <div className="mt-12 rounded-3xl border border-white/10 bg-gradient-to-r from-gold/10 to-transparent p-6">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          <div>
            <h2 className="text-xl font-display font-bold text-white">Bundles sur-mesure</h2>
            <p className="mt-1 text-sm text-white/70">On te crée un pack (PLR, templates, ads) pour ton secteur.</p>
          </div>
          <Button className="bg-gold text-black hover:bg-gold/90">Demander un pack</Button>
        </div>
      </div>
    </div>
  );
}
