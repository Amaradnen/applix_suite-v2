"use client";

import { useMemo, useState } from "react";
import type { CardMaterial } from "./templates";

type Props = {
  material: CardMaterial;
  name: string;
  title: string;
  slug: string;
  onNameChange: (v: string) => void;
  onTitleChange: (v: string) => void;
};

function bg(material: CardMaterial) {
  if (material === "metal-black") return "linear-gradient(135deg, #101010 0%, #000 100%)";
  if (material === "metal-gold") return "linear-gradient(135deg, #F3D77C 0%, #B88A11 100%)";
  return "#ffffff";
}

/**
 * NFC Card preview (Golden Gemini).
 * - Editable text is *inside the card* (no external name/title inputs)
 * - Flip happens ONLY via the button (so editing won't accidentally flip)
 */
export default function CardPreview({ material, name, title, slug, onNameChange, onTitleChange }: Props) {
  const [isFlipped, setIsFlipped] = useState(false);
  const text = material === "pvc-white" ? "text-black" : "text-white";
  const muted = material === "pvc-white" ? "text-black/60" : "text-white/60";
  const border = material === "pvc-white" ? "border-black/10" : "border-white/10";

  const front = useMemo(() => {
    return (
      <div className="h-full w-full p-8 flex flex-col justify-between">
        <div className="flex items-start justify-between">
          <div className={`w-10 h-6 rounded border ${border}`} />
          <div className="text-gold text-xs font-bold tracking-widest">APPLIX</div>
        </div>

        <div>
          <input
            value={name}
            onChange={(e) => onNameChange(e.target.value)}
            onClick={(e) => e.stopPropagation()}
            onPointerDown={(e) => e.stopPropagation()}
            spellCheck={false}
            className={[
              "w-full bg-transparent outline-none border-0 p-0",
              text,
              "font-display font-bold text-2xl",
              "placeholder:opacity-60",
            ].join(" ")}
            placeholder="Nom"
          />
          <input
            value={title}
            onChange={(e) => onTitleChange(e.target.value)}
            onClick={(e) => e.stopPropagation()}
            onPointerDown={(e) => e.stopPropagation()}
            spellCheck={false}
            className={[
              "w-full bg-transparent outline-none border-0 p-0 mt-1",
              muted,
              "text-[10px] tracking-widest uppercase",
              "placeholder:opacity-60",
            ].join(" ")}
            placeholder="Titre / Poste"
          />
        </div>

        <div className={`${muted} text-[10px] tracking-widest uppercase flex items-center justify-between`}>
          <span>NFC • Golden Gemini</span>
          <span className="text-gold/80">Tap</span>
        </div>
      </div>
    );
  }, [border, muted, name, onNameChange, onTitleChange, text, title]);

  const back = useMemo(() => {
    return (
      <div className="h-full w-full p-8 flex items-center justify-between">
        <div>
          <div className="text-white/50 text-[10px] tracking-widest font-bold">APPLIX ID</div>
          <div className="text-white/40 text-xs mt-2 font-mono">SN: 8829-1029-EXP</div>
          <div className="text-white/40 text-xs mt-2">URL: /u/{slug}</div>
        </div>
        <div className="w-24 h-24 bg-white rounded-xl p-2">
          <div className="w-full h-full bg-black/10 rounded-lg flex items-center justify-center text-xs text-black/60">
            QR
          </div>
        </div>
      </div>
    );
  }, [slug]);

  return (
    <div className="relative">
      <div className="absolute top-4 right-4 z-20">
        <button
          type="button"
          onClick={() => setIsFlipped((v) => !v)}
          className="px-4 py-2 rounded-full text-xs font-bold border border-white/10 bg-black/50 hover:bg-black transition"
        >
          {isFlipped ? "Voir recto" : "Voir verso"}
        </button>
      </div>

      <div
        className={[
          "relative w-[360px] sm:w-[400px] h-[225px] sm:h-[250px] rounded-2xl shadow-2xl",
          "transition-transform duration-700 [transform-style:preserve-3d]",
        ].join(" ")}
        style={{ transform: isFlipped ? "rotateY(180deg)" : "rotateY(0deg)" }}
      >
        <div
          className="absolute inset-0 rounded-2xl overflow-hidden [backface-visibility:hidden]"
          style={{ background: bg(material) }}
        >
          {/* Golden Gemini: subtle radial gold glow */}
          <div
            className="absolute inset-0 opacity-30"
            style={{
              backgroundImage:
                "radial-gradient(circle at 22% 10%, rgba(227,181,46,0.35), transparent 55%), radial-gradient(circle at 80% 80%, rgba(227,181,46,0.12), transparent 60%)",
            }}
          />
          {front}
        </div>

        <div
          className="absolute inset-0 rounded-2xl overflow-hidden [backface-visibility:hidden] [transform:rotateY(180deg)]"
          style={{ background: "#111", border: "1px solid rgba(255,255,255,0.12)" }}
        >
          {back}
        </div>
      </div>

      <div className="text-center text-[10px] text-white/40 mt-4 tracking-widest uppercase">
        Cliquez sur le texte pour modifier • Retournez uniquement avec le bouton
      </div>
    </div>
  );
}
